﻿using System;

namespace Store.ApplicationCore.Exceptions
{
    public class NotFoundException : Exception
    {
    }
}